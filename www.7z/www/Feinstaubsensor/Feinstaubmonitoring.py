import sys
import os

import time
import string
import struct
import csv

import datetime
from datetime import date

from threading import Thread
import threading

import json

from flask import Flask, jsonify, render_template, request

import serial
from gps import *



# Hier wird der Speicherort fuer die CSV Dateien festgelegt.
global dir_path
dir_path = "/var/www/Feinstaubsensor/"

# USB Geraetepfad des Feinstaubsensors bitte hier setzen.
sds011 = "/dev/ttyUSB0"


# Zykluszeit in Sekunden
global Zykluszeit
Zykluszeit = 3600

global time_on
time_on = time.time() + Zykluszeit
global time_on_old
time_on_old = time.time()

global time_off
time_off = time.time() +50

global sensor_state
sensor_state = 1

global array_day
global array_month
array_month = [[0,0,0]]
global array_year
array_yaer = [[0,0,0]]

global session
session = None

global g_lat, g_lng, g_utc
g_lat = 0
g_lng = 0
g_utc = datetime.datetime.utcnow()

global run
run = False

global status_text
status_text = "inaktiv"

global display_lat
global display_lon

display_lat = "keine GPS Aufzeichnung aktiv"
display_lon = "keine GPS Aufzeichnung aktiv"

global pm_10
global pm_25
pm_10 = 0
pm_25 = 0


# Default Farbe fuer die Weg-Linie in der KML Datei.
color = "#00000000" 
    

# Hier wird die Farbe fuer die Linie festgelegt.
def color_selection(value):
    # red   
    if 50 <= value:
        color = "#641400F0"
    # orange
    elif 25 <= value <= 49:
        color = "#641478FF"
    # green
    elif 0 <= value < 25:
        color = "#64009614"     
        
    return color

# und hier fuer die Darstellung im Frontend 
def color_selection_rgb(value):
    # red   
    if 50 <= value:
        color = "#F00014"
    # orange
    elif 25 <= value <= 49:
        color = "#FF7814"
    # green
    elif 0 <= value < 25:
        color = "#2bef0d"       
        
    return color

	
	
	
	
# Diese Funktionen schreibten die CSV Datei mit den Feinstaubwerten und
# den GPS Koordinaten.
def write_csv(pm_25, pm_10, value_time,value_daytime,value_fname):
    #pm_25 = string.replace(pm_25, ".", ",")
    #pm_10 = string.replace(pm_10, ".", ",")
    time = value_time
    daytime= value_daytime
    fname = value_fname
    with open(fname,'a') as file:
        line = ""+pm_25+";"+pm_10+";"+time+";"+daytime
        file.write(line)
        file.write('\n')
        file.close()

def write2_csv(pm_25, pm_10, value_time,value_fname):
   # pm_25 = string.replace(pm_25, ".", ",")
   #pm_10 = string.replace(pm_10, ".", ",")
    time = value_time
    fname = value_fname
    with open(fname,'a') as file:
        line = ""+pm_25+";"+pm_10+";"+time
        file.write(line)
        file.write('\n')
        file.close()

def overwrite2_csv(pm_25, pm_10, value_time,value_fname):
   # pm_25 = string.replace(pm_25, ".", ",")
    #pm_10 = string.replace(pm_10, ".", ",")
    time = value_time
    fname = value_fname
    with open(fname,'wb') as file:
        line = ""+pm_25+";"+pm_10+";"+time
        file.write(line)
        file.write('\n')
        file.close()


def overwrite_csv(pm_25, pm_10, value_time,value_daytime,value_fname):
    #pm_25 = string.replace(pm_25, ".", ",")
    #pm_10 = string.replace(pm_10, ".", ",")
    time = value_time
    daytime= value_daytime
    fname = value_fname
    with open(fname,'wb') as file:
        line = ""+pm_25+";"+pm_10+";"+time+";"+daytime
        file.write(line)
        file.write('\n')
        file.close()



# Klasse um auf den GPSD Stream via Thread zuzugreifen.
class GpsdStreamReader(threading.Thread):
    def __init__(self):
        global session
        global g_lat, g_lng, g_utc
        threading.Thread.__init__(self)

        session = gps(mode=WATCH_ENABLE)
        g_utc = session.utc
        g_lat = session.fix.latitude
        g_lng = session.fix.longitude
        self.current_value = None
        # Der Thread wird ausgefuehrt
        self.running = True
 
    def run(self):
        global session
        global g_lat, g_lng, g_utc

        counter = 0
        
        while t_gps.running:
            # Lese den naechsten Datensatz von GPSD
            session.next()    
            g_utc = session.utc
            if(session.fix.latitude != 0):
                g_lat = session.fix.latitude
                g_lng = session.fix.longitude



# Klasse um auf den SDS001 Sensor via Thread zuzugreifen.
class SDS001StreamReader(threading.Thread):
    def __init__(self):
        global byte
        global lastbyte
        global ser
        
        # Variablen fuer die Messwerte vom Feinstaubsensor.
        byte, lastbyte = "\x00", "\x00" 
        threading.Thread.__init__(self)

        
            # Hier wird auf den Serial-USB Konverter zugegriffen
        try:
            ser = serial.Serial(sds011, baudrate=9600, stopbits=1, parity="N", timeout=2)
        except Exception as e:
            print("\n HL-340 USB-Serial Adapter nicht verfuegbar. \n"+str(e))

        try:
            ser.flushInput()
        except Exception as e:
            print(e)
        
        self.current_value = None
        # Der Thread wird ausgefuehrt
        self.running = True
 
    def run(self):
        global pm_25
        global pm_10
        global byte
        global lastbyte
        global ser
        global time_on
        global sensor_state

        old_sensor_state = 0
        Send_timer = time.time() + 30
        counter = 0

        
        while t_sds011.running:     
            if (sensor_state != old_sensor_state):
                old_sensor_state = sensor_state
                Send_timer = time.time() + 30
                counter = 0
                
                if (sensor_state == 1):
                    try:
                        ser.flushInput()
                    except Exception as e:
                        print(e)

                    time.sleep(1)

                if sensor_state==0:
                    time.sleep(time_on-(time.time()+5))
                 
            if (counter < 4 and sensor_state == 1 and time.time() >= Send_timer):
                counter += 1
                lastbyte = byte
                
                try:
                     byte = ser.read(size=1)
                except Exception as e:
                     print("\n Fehler HL-340 USB-Serial Adapter.\n"+str(e))

                # Wenn es ein gueltiges Datenpaket gibt bearbeite dieses
                if lastbyte == "\xAA" and byte == "\xC0":
                    try:
                     # Es werden 8 Byte eingelesen.
                        sentence = ser.read(size=8) 
                        # Das eingelesene Datenpaket wird dekodiert.
                        readings = struct.unpack('<hhxxcc',sentence)
                    except Exception as e:
                         print(("\n SDS011 Datenpaket kann nicht gelesen werden. \n"+str(e)))
                         
                    if (round(readings[0]/10.0, 3) != 0):
                        pm_25 = round(readings[0]/10.0, 3)
                        pm_10 = round(readings[1]/10.0, 3)

                        print("Feinstaubwerte: ",pm_10,pm_25)



    
	
	

	
# Klasse um Durchschnittswerte zu bilden und zu speichern.
class Save_values(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.current_value = None
        # Der Thread wird ausgefuehrt
        self.running = True
        
    def run(self):
        global sensor_state
        global dir_path
        global pm_10
        global pm_25
        global pm_10_sum
        global pm_25_sum
        global avg_count
        global array_day
        global array_month
        global array_year
        global time_on
        global time_on_old

        old_sensor_state = 0
        Send_timer = time.time() + 28
        save_file = False
        save_file2 = False
        save_file3 = False
        pm_10_sum = 0
        pm_25_sum = 0
        pm_10_sum2 = 0
        pm_25_sum2 = 0
        pm_25_av = 0
        pm_10_av = 0
        pm_25_av2 = 0
        pm_10_av2 = 0
        avg_count = 0
        avg_count2 = 0
        row_count = 0
        rowcount_m = 0
        rowcount_y = 0


        while t_save.running:
            if (sensor_state != old_sensor_state and time.time() >= (time_on_old + 40)):
                old_sensor_state = sensor_state
 
                if sensor_state==0:
                    time.sleep(time_on-(time.time()+5))
            
                if (sensor_state == 1):
                    print("start saving values")

                    if save_file == False:
                        # micro-sd card paths for the file
                        fname_csv = dir_path+'Tageswerte'+'.csv'
                    save_file = True

                    with open(dir_path+'Tageswerte'+'.csv') as csv_file:
                        csv_reader = csv.reader(csv_file, delimiter='.')
                        row_count = sum(1 for row in csv_reader) 
                        
                    pm_25_t =string.replace(str(pm_25), ".", ",")
                    pm_10_t =string.replace(str(pm_10), ".", ",")
                    
                    if (2000> pm_25 != 0 and 2000 > pm_10 != 0):
                        #24 Werte am Tag, am Tag jede Stunde
                        if row_count < 24:
                            write_csv((pm_25_t), (pm_10_t), str(time.mktime(datetime.datetime.now().timetuple())*1000),datetime.datetime.now().strftime ("%H:%M:%S"), fname_csv)
                            array_day.append([(pm_25_t),(pm_10_t), str(time.mktime(datetime.datetime.now().timetuple())*1000),datetime.datetime.now().strftime ("%H:%M:%S")]) 
                            

                        else:
                            #Werte um einen Platz verschieben
                            for i in range(1,24): 
                                array_day[i-1] = array_day[i]

                            array_day[23] = [(pm_25_t),(pm_10_t), str(time.mktime(datetime.datetime.now().timetuple())*1000),datetime.datetime.now().strftime ("%H:%M:%S")]
                            overwrite_csv(array_day[0][0], array_day[0][1], array_day[0][2],array_day[0][3],fname_csv)

                            for i in range(1,24):
                                
                                write_csv(array_day[i][0], array_day[i][1], array_day[i][2],array_day[i][3],fname_csv)


                    #Tagesdurchschnittswerte bilden und Zwischenspeichern
                    rowcount_m = len(array_month)
                    if ((float(array_month[rowcount_m-1] [2])/1000) +82800 < time.time() and datetime.datetime.now().hour > 22):   
                        if save_file2 == False:
                        # micro-sd card paths for the file
                            fname2_csv = dir_path+'Tagesdurchschnittswerte'+'.csv'
                        save_file2 = True

                        for i in range(0,row_count):
                            date_i = time.localtime((float(array_day[i][2]))/1000)
                            if (datetime.datetime.now().year == date_i[0] and datetime.datetime.now().month == date_i[1] and datetime.datetime.now().day == date_i[2]):
                                pm_25_i =float((array_day[i][0]).replace(',','.'))
                                pm_10_i =float((array_day[i][1]).replace(',','.'))
                                pm_25_sum +=  pm_25_i
                                pm_10_sum += pm_10_i
                                avg_count += 1
                                
                            
                            if (i+1 == row_count and avg_count != 0):
                                pm_25_av = pm_25_sum / avg_count
                                pm_10_av = pm_10_sum / avg_count
                                pm_25_av = str(round(pm_25_av, 3))
                                pm_10_av = str(round(pm_10_av, 3))
                                pm_25_av =string.replace(pm_25_av, ".", ",")
                                pm_10_av =string.replace(pm_10_av, ".", ",")
                                print( pm_25_sum, pm_10_sum,avg_count)

                                if (rowcount_m < 31):
                                    array_month.append([(pm_25_av), (pm_10_av), str(time.mktime(datetime.datetime.now().timetuple())*1000)])
                                    write2_csv((pm_25_av), (pm_10_av), str(time.mktime(datetime.datetime.now().timetuple())*1000),fname2_csv)
                                    print("Tagesdurchschnitt gespeichert")
                                else:
                                    for i in range(1,31):
                                        array_month[i-1] = array_month[i]
                                        


                                    array_month[30] = ([(pm_25_av), (pm_10_av), str(time.mktime(datetime.datetime.now().timetuple())*1000)])
                                    print("Tagesdurchschnitt gespeichert")
                                    overwrite2_csv(array_month[0][0], array_month[0][1], array_month[0][2],fname2_csv)

                                    for i in range(0,31):
                                       
                                        write2_csv(array_month[i][0], array_month[i][1], array_month[i][2],fname2_csv)
                                        

                
                #Monatsdurchschnittswerte bilden und zwischenspeichern                    
                    rowcount_y = len(array_year)
                    prev_month = time.localtime((float(array_year[rowcount_y-1][2]))/1000)
                    this_month = time.localtime(time.time())
                    day_in_mth =(date(this_month[0],(this_month[1])+1, 1) - date(this_month[0],this_month[1], 1)).days
                    
                    
                    if ( prev_month[1] != this_month[1] and this_month[2] == day_in_mth and datetime.datetime.now().hour > 22):
                        if save_file3 == False:
                        # micro-sd card paths for the file
                            fname3_csv = dir_path+'Monatsdurchschnittswerte'+'.csv'
                        save_file3 = True

                        for i in range(0,rowcount_m):
                            date_m = time.localtime((float(array_month[i][2]))/1000)
                            if (datetime.datetime.now().year == date_m[0] and datetime.datetime.now().month == date_m[1]):
                                pm_25_m =float((array_month[i][0]).replace(',','.'))
                                pm_10_m =float((array_month[i][1]).replace(',','.'))
                                pm_25_sum2 +=  pm_25_m
                                pm_10_sum2 += pm_10_m
                                avg_count2 += 1                    

                            if (i+1 == rowcount_m and avg_count2 != 0):
                                pm_25_av2 = pm_25_sum2 / avg_count2
                                pm_10_av2 = pm_10_sum2 / avg_count2
                                pm_25_av2 = str(round(pm_25_av2, 3))
                                pm_10_av2 = str(round(pm_10_av2, 3))
                                pm_25_av2 =string.replace(pm_25_av2, ".", ",")
                                pm_10_av2 =string.replace(pm_10_av2, ".", ",")
                                #print( pm_25_sum2, pm_10_sum2,avg_count2)


                                array_year.append([(pm_25_av2), (pm_10_av2), str(time.mktime(datetime.datetime.now().timetuple())*1000),datetime.datetime.now().strftime ("%Y-%m")])
                                write_csv((pm_25_av2), (pm_10_av2), str(time.mktime(datetime.datetime.now().timetuple())*1000),datetime.datetime.now().strftime ("%Y-%m"),fname3_csv)







# Diese Funktion oeffnet die CSV Datei mit den Feinstaubwerten und der Zeit

with open(dir_path+'Tageswerte'+'.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=';')
    line_count = 0
    array_day=list(csv_reader)
    
with open(dir_path+'Tagesdurchschnittswerte'+'.csv') as csv_file:
    csv_reader2 = csv.reader(csv_file, delimiter=';')
    line_count = 0
    array_month=list(csv_reader2)

with open(dir_path+ 'Monatsdurchschnittswerte'+'.csv') as csv_file:
    csv_reader3 = csv.reader(csv_file, delimiter=';')
    line_count = 0
    array_year=list(csv_reader3)







# Klasse um den Sensor schlafen zu legen.
class sleepSensor(threading.Thread):
    def __init__(self):
        global byte
        global lastbyte
        global ser
        byte, lastbyte = "\x00", "\x00" 
        
                
        threading.Thread.__init__(self)
    
        try:
            ser = serial.Serial(sds011, baudrate=9600, stopbits=1, parity="N", timeout=2)
        except Exception as e:
            print("\n HL-340 USB-Serial Adapter nicht verfuegbar. \n"+str(e))

        try:
            ser.flushInput()
        except Exception as e:
            print(e)

        self.current_value = None
        # Der Thread wird ausgefuehrt
        self.running = True

        
        
    def run(self):
        global sensor_state
        global Zykluszeit
        global time_on
        global time_off
        global ser
        global byte
        global lastbyte
        old_sensor_state = 0
        
        while t_sleep.running:

                if (sensor_state != old_sensor_state):
                    old_sensor_state = sensor_state
                    
                    if sensor_state==0:
                    
                        time.sleep(time_on-(time.time()+5))
                        #print("sleep:")
                
                if sensor_state==1 and time.time() >= time_off:
                    

                    #print("sleeping1",time.time())
                    bytes = ['\xaa', #head
                                '\xb4', #command 1
                                '\x06', #data byte 1
                                '\x01', #data byte 2 (set mode)
                                '\x00', #data byte 3 (sleep)
                                '\x00', #data byte 4
                                '\x00', #data byte 5
                                '\x00', #data byte 6
                                '\x00', #data byte 7
                                '\x00', #data byte 8    
                                '\x00', #data byte 9
                                '\x00', #data byte 10
                                '\x00', #data byte 11
                                '\x00', #data byte 12
                                '\x00', #data byte 13
                                '\xff', #data byte 14 (device id byte 1)
                                '\xff', #data byte 15 (device id byte 2)
                                '\x05', #checksum
                                '\xab'] #tail

                    for b in bytes:
                            ser.write(b)
                    time.sleep(1)
                    try:
                        ser.flushInput()
                    except Exception as e:
                        print(e)

                    time.sleep(1)
                    lastbyte = byte
                    try:
                        byte = ser.read(size=1)
                    except Exception as e:
                        print("\n Fehler HL-340 USB-Serial Adapter.\n"+str(e))
                    
                        

                    while (byte != ""):
                        bytes = ['\xaa', #head
                            '\xb4', #command 1
                            '\x06', #data byte 1
                            '\x01', #data byte 2 (set mode)
                            '\x00', #data byte 3 (sleep)
                            '\x00', #data byte 4
                            '\x00', #data byte 5
                            '\x00', #data byte 6
                            '\x00', #data byte 7
                            '\x00', #data byte 8    
                            '\x00', #data byte 9
                            '\x00', #data byte 10
                            '\x00', #data byte 11
                            '\x00', #data byte 12
                            '\x00', #data byte 13
                            '\xff', #data byte 14 (device id byte 1)
                            '\xff', #data byte 15 (device id byte 2)
                            '\x05', #checksum
                            '\xab'] #tail

                        for b in bytes:
                            ser.write(b)

                        time.sleep(1)
                        try:
                            ser.flushInput()
                        except Exception as e:
                            print(e)
                        time.sleep(1)
                        try:
                            byte = ser.read(size=1)
                        except Exception as e:
                            print("\n Fehler HL-340 USB-Serial Adapter.\n"+str(e))


                    time_off = time_on + 50
                    print("sleeping")
                    sensor_state=0

                    


# Klasse um den Sensor aufzuwecken.
class wakeSensor(threading.Thread):
    def __init__(self):
        global ser
                
        threading.Thread.__init__(self)
        self.current_value = None
        # Der Thread wird ausgefuehrt
        self.running = True

        
        
    def run(self):
        global time_on
        global sensor_state
        global ser
        global time_on_old
        global Zykluszeit
        old_sensor_state = 0
        
        while t_wake.running:
                if (sensor_state != old_sensor_state):
                    old_sensor_state = sensor_state
                    
                    if sensor_state==0:
                        time.sleep(time_on-(time.time()+5))
                
                if time.time() >= time_on and sensor_state==0:
                    bytes = ['\xaa', #head
                                '\xb4', #command 1
                                '\x06', #data byte 1
                                '\x01', #data byte 2 (set mode)
                                '\x01', #data byte 3 (sleep)
                                '\x00', #data byte 4
                                '\x00', #data byte 5
                                '\x00', #data byte 6
                                '\x00', #data byte 7
                                '\x00', #data byte 8
                                '\x00', #data byte 9
                                '\x00', #data byte 10
                                '\x00', #data byte 11
                                '\x00', #data byte 12
                                '\x00', #data byte 13
                                '\xff', #data byte 14 (device id byte 1)
                                '\xff', #data byte 15 (device id byte 2)
                                '\x05', #checksum
                                '\xab'] #tail
                    for b in bytes:
                        ser.write(b)
                        
                    time_on_old= time_on
                    time_on = time.time() + Zykluszeit
                    print("awake")
                    sensor_state=1
                
                


# Klasse zum Speichern der Daten in eine virtuelle Datei.
class Send_data(threading.Thread):
    def __init__(self):

        threading.Thread.__init__(self)
        self.current_value = None
        # Der Thread wird ausgefuehrt
        self.running = True

        
        
    def run(self):
        global status_text
        global display_lat
        global display_lon
        global pm_10
        global pm_25
        global time_on
        global time_on_old
        global Zykluszeit

        old_sensor_state = 0

        display_lat = "%.5f" % float(g_lat)
        display_lon = "%.5f" % float(g_lng)

        while t_send.running:
            if (sensor_state != old_sensor_state and time.time() >= (time_on_old + 45)):
                old_sensor_state = sensor_state
                
                if sensor_state==0:
                    print("ruhezeit_threads:",time_on-(time.time()+5))
                    time.sleep(time_on-(time.time()+5))

                if (sensor_state==1):
                    print("json safe")
                    data = {"value": status_text, "lat": display_lat, "lon": display_lon,
                        "pm_10": "%6.1f" % pm_10, "pm_10_color": color_selection_rgb(pm_10),
                        "pm_25": "%6.1f" % pm_25, "pm_25_color": color_selection_rgb(pm_25),
                        "time_on": time_on,"array_day": array_day,"array_month": array_month,"array_year": array_year}

                    with open('/virtual/data.json', 'w') as outfile:  
                        json.dump(data, outfile)
                    


                    

if __name__ == '__main__':
    # Start des Threads der den GPS Empfaenger ausliesst.
    t_gps = GpsdStreamReader()
    t_gps.start()

    # Start des Threads der den Feinstaubsensor ueber den USB-Serial
    # Konverter ausliesst.
    t_sds011 = SDS001StreamReader()
    t_sds011.start()

    #Start des Threads der die Messwerte zwischenspeichert und
    #Durchschnitte bilden
    t_save=Save_values()
    t_save.start()

    #Start des Threads der den Feinstaubsensor schlafen legt
    t_sleep = sleepSensor()
    t_sleep.start()

    #Start des Threads der den Feinstaubsensor aufweckt
    t_wake = wakeSensor()
    t_wake.start()

    #Start des Threads der der die Daten uebergibt   
    t_send = Send_data()
    t_send.start()
